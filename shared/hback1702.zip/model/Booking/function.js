const jwt = require('jsonwebtoken');
const moment = require('moment');
const Query = require('../../lib/query');
const { errorName } = require('../../middleware/errorContant');

exports.getbookinghistoryforuser = async function (args) {

  var queryforlist = "SELECT bookings.id as booking_id,bookings.from_location,bookings.destination_address,trips.departure_date_time FROM `bookings` LEFT JOIN trips on trips.id = bookings.trip_id WHERE bookings.booking_status ='"+args.status+"' and bookings.rider_id ="+args.user_id;
  
  var resultoflist = await Query.queryForList(queryforlist);
  console.log(queryforlist)
  if (resultoflist.length > 0) {
  //  var list = [];
  //  list.push(resultoflist);
   return { list: resultoflist, statusCode: 200, message: 'Booking List' };
 } else {
   return { list:[], statusCode: 200, message: 'No Booking Found!' };
 }
};
exports.getbookingdetailforhistory = async function (args) {
 
 // get booking details
 var q = "SELECT trips.price,trips.id as trip_id,trips.from_location,trips.from_lat,trips.from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,trips.driver_id,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.about as driver_about,TIMESTAMPDIFF(YEAR, users.dob, CURDATE()) AS driver_age,users.gender as driver_gender,users.total_ride_taken as driver_total_ride_taken,CONCAT_WS('-', vehicles.model,vehicles.brand_name ) AS vehicle_name,CONCAT_WS(' ', vehicles.color,vehicles.model_year) AS vehicle_info,vehicles.photo as vehicle_photo,CASE trip_facilities.luggage_type when '1' then 'No' when '2' then 'Small' when '3' then 'medium' when '4' then 'Large'  ELSE '' END AS luggage_type,trip_facilities.back_side_seat_for_two_only,trip_facilities.smoking_allow,trip_facilities.reach_on_time,trip_facilities.drinking_allow,trip_facilities.pets_allow,trip_facilities.wear_face_mask,bookings.id,bookings.booked_seat,bookings.from_location,bookings.destination_address,bookings.base_fare,bookings.extra_amount,bookings.extra_amount,bookings.discount_amount,bookings.total_fare,bookings.coupon_code,bookings.message,bookings.payment_status,bookings.booking_status,bookings.remark,bookings.cancelled_by,trips.departure_date_time, users.first_name as driver_first_name,users.middle_name as driver_middle_name,users.last_name as driver_last_name,users.profile_pic as driver_profile_pic FROM `bookings` LEFT JOIN trips on trips.id = bookings.trip_id INNER JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id LEFT JOIN trip_facilities on trip_facilities.trip_id = trips.id WHERE bookings.id = " + args.booking_id;

 var qresult = await Query.queryForList(q);
 console.log(qresult)
 var trip_id=qresult[0].trip_id;
 var getstops =
    "select destination_address,destination_lat,destination_lng,departure_date_time,no_of_seat,price from trip_stops where trip_id=" +
    trip_id;
  var getstopsresult = await Query.queryForList(getstops);
  var getbooking =
    "select bookings.id as booking_id,bookings.booked_seat,bookings.from_location,bookings.from_lat,bookings.from_lng,bookings.destination_address,bookings.destination_lat,bookings.destination_lng,bookings.base_fare,bookings.extra_amount,bookings.discount_amount,bookings.total_fare,bookings.coupon_id,bookings.coupon_code,bookings.message,bookings.payment_status,bookings.booking_status,bookings.remark,users.id as rider_id,users.first_name as rider_first_name,users.last_name as rider_last_name,users.email as rider_email,users.mobile as rider_mobile,users.gender as rider_gender from bookings  left join users on users.id = bookings.rider_id where bookings.trip_id=" +
    trip_id;
  var getbookingresult = await Query.queryForList(getbooking);
  console.log("Booking",getbooking)

  var getPaymentPreAuth = await Query.findsinglerecord('payment_pre', {
    booking_id: args.booking_id,
    complete:'true'
  });
  var paymentPreAuthStatus = false;
  var paymentPreAuthCompleteStatus = false;
  if(getPaymentPreAuth){
    paymentPreAuthStatus = true;
    var getPaymentPreAuthComplete = await Query.findsinglerecord('payment_preauth', {
      booking_id: args.booking_id,
      payment_pre_id:getPaymentPreAuth.id,
      complete:'true'
    });
    if(getPaymentPreAuthComplete){
      paymentPreAuthCompleteStatus = true;
    }
  }
  qresult[0].stops=getstopsresult;
  qresult[0].bookings=getbookingresult;
  qresult[0].paymentPreAuthStatus=paymentPreAuthStatus;
  qresult[0].paymentPreAuthCompleteStatus=paymentPreAuthCompleteStatus;


 return { list: qresult[0], statusCode: 200, message: "Booking Details" };
};