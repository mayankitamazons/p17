const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
  GraphQLObjectType,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

const count_schema = require("./type").count_schema;
const ChatFunction = require("./function");
const { errorName } = require("../../middleware/errorContant");

var c_fields = {
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var update_schema = new GraphQLObjectType({
  name: "UpdateChat",
  description: "update",
  fields: c_fields,
});

module.exports = {
  createchat: {
    type: update_schema,
    description: "Create Chat",
    args: {
      trip_id: { type: GraphQLInt },
      booking_id: { type: GraphQLInt },
      sender_id: { type: GraphQLInt },
      receiver_id: { type: GraphQLInt },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          trip_id: value("trip_id").notEmpty(),
          sender_id: value("sender_id").notEmpty(),
          receiver_id: value("receiver_id").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          // args.token_user_id = verifiedUser.user_id;
          return ChatFunction.createchat(args);
        }
      }
    },
  },
};
