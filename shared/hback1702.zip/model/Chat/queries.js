const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require("graphql");
const type = require("./type").schema;
const { validate, ValidationError } = require("validator-fluent");
const { errorName } = require("../../middleware/errorContant");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const ChatFunction = require("./function");

var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  totalRecord: {
    type: GraphQLInt,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var list_schema = new GraphQLObjectType({
  name: "ChatList",
  description: "List",
  fields: c_fields,
});

module.exports = {
  getchatlist: {
    type: list_schema,
    description: "Chat list of user id",
    args: {
      user_id: { type: GraphQLID },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          user_id: value("user_id").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return ChatFunction.getchatlist(args);
        }
      }
    },
  },
  getlist: {
    type: list_schema,
    description: "Retrieves list as per given table and conditions",
    args: {
      table: { type: GraphQLString },
      condition: { type: GraphQLJSON },
      limit: { type: GraphQLInt },
      offset: { type: GraphQLInt },
      order: { type: GraphQLJSON },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          table: value("table").notEmpty(),
          condition: value("condition").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return CommonFunction.getlist(args);
        }
      }
    },
  },
};
