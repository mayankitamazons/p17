const jwt = require('jsonwebtoken');
const moment = require('moment');
const Query = require('../../lib/query');
const { errorName } = require('../../middleware/errorContant');
const { curly } = require('node-libcurl')
const COMMON = require('../../shared/common');
// moment.tz.setDefault("America/New_York");
exports.createtripstepone = async function (args) {
  if (args.driver_id == args.token_user_id) {
    var userdata = await Query.findsinglerecord('users', {
      id: args.token_user_id,
    });
    if (userdata) {
      // check driver profile is active or not
      if (userdata.status == '1') {
        if (userdata.driver_id_verified) {
        
          
          let tripData = {
            driver_id: args.driver_id,
            from_location: args.from_location,
            from_lat: args.from_lat,
            from_lng: args.from_lng,
            destination_address: args.destination_address,
            destination_lat: args.destination_lat,
            destination_lng: args.destination_lng,
            no_of_seat: args.no_of_seat
          };
          if(args.trip_request_id){
            tripData.trip_request_id = args.trip_request_id;
          }
          let insertresult = await Query.insert('trips', {
            data: tripData,
          });

          if (insertresult.affectedRows > 0) {

            // from as a first stop
            var stopListFrom = {
              trip_id: insertresult.insertId,
              destination_address: args.from_location,
              destination_lat: args.from_lat,
              destination_lng: args.from_lng,
              no_of_seat: args.no_of_seat,
            };
            let insertresultFrom = await Query.insert('trip_stops', {
              data: stopListFrom,
            });

            // final destination as last stop
            var stopListdestination = {
              trip_id: insertresult.insertId,
              destination_address: args.destination_address,
              destination_lat: args.destination_lat,
              destination_lng: args.destination_lng,
              no_of_seat: args.no_of_seat,
            };
            let insertresultdestination = await Query.insert('trip_stops', {
              data: stopListdestination,
            });


            var stops = [];
            if (args.stop) {
              args.stop.forEach((stop) => {
                var stopList = {
                  trip_id: insertresult.insertId,
                  destination_address: stop.destination_address,
                  destination_lat: stop.destination_lat,
                  destination_lng: stop.destination_lng,
                  price: stop.price,
                  no_of_seat: args.no_of_seat,
                };
                stops.push(stopList);
              });
              if (stops.length > 0) {
                let bulkInsert = await Query.bulkInsert('trip_stops', {
                  data: stops,
                });
              }
            }
            var trip = await Query.findsinglerecord('trips', {
              id: insertresult.insertId,
            });
            return trip;
          } else {
            var err = new Error(errorName.WENT_WRONG);
            throw err;
          }
        } else {
          var err = new Error(errorName.DRIVER_ID_NOT_VERIFIED);
          throw err;
        }
      } else {
        var err = new Error(errorName.ACCOUNT_NOT_ACTIVE);
        throw err;
      }
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.createtripsteptwo = async function (args) {
  // console.log('req 2',args);
  if (args.driver_id == args.token_user_id) {
    var trecord = await Query.findsinglerecord('trips', {
      driver_id: args.token_user_id,
      id: args.trip_id, 
    });
    if (trecord) {
      let tripData = {
        trip_type: args.trip_type,
        trip_schedule: args.trip_schedule,
        // departure_date_time: args.departure_date_time,
        departure_date_time: moment(args.departure_date_time).format('YYYY/MM/DD HH:MM'),
       
      };
      if(args.return_date_time)
      {
        // tripData.return_date_time=args.return_date_time;
      tripData.return_date_time=moment(args.return_date_time).format('YYYY/MM/DD HH:MM');

      }
      
      var updatetrip = await Query.update('trips', {
        data: tripData,
        id: args.trip_id,
      });
      if (updatetrip.affectedRows > 0) {
        var recurrings = [];
        if (args.recurring) {
          args.recurring.forEach((recurring) => {
            var recurringList = {
              trip_id: args.trip_id,
              trip_date: recurring.trip_date,
            };
            recurrings.push(recurringList);
          });
          if (recurrings.length > 0) {
            let bulkInsert = await Query.bulkInsert('recurring_trips', {
              data: recurrings,
            });
          }
        }
        var trip = await Query.findsinglerecord('trips', {
          id: args.trip_id,
        });
        return trip;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.createtripstepfinal = async function (args) {
  if (args.driver_id == args.token_user_id) {
    let tripData = {
      trip_id: args.trip_id,
      luggage_type: args.luggage_type,
      back_side_seat_for_two_only: args.back_side_seat_for_two_only,
      smoking_allow: args.smoking_allow,
      drinking_allow: args.drinking_allow,
      pets_allow: args.pets_allow,
      reach_on_time: args.reach_on_time,
      wear_face_mask: args.wear_face_mask,
      
      
    };

    let insertresult = await Query.insert('trip_facilities', {
      data: tripData,
    });

    if (insertresult) {
      var updatetrip = await Query.update('trips', {
        data: { status: '1',price:args.price_per_seat },
        id: args.trip_id,
      });
      // offer mail create here
      var trip = await Query.findsinglerecord('trips', {
        id: args.trip_id,
      });
      return trip;
    } else {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.updatetrip = async function (args) {
  if (args.driver_id == args.token_user_id) {
    var trecord = await Query.findsinglerecord('trips', {
      driver_id: args.token_user_id,
      id: args.trip_id,
    });
    if (trecord) {
      var t = {};
      if (args.no_of_seat) t.no_of_seat = args.no_of_seat;
      if (args.from_location) t.from_location = args.from_location;
      if (args.from_lat) t.from_location = args.from_lat;
      if (args.from_lng) t.from_location = args.from_lng;
      if (args.destination_address) t.from_location = args.destination_address;
      if (args.destination_lat) t.from_location = args.destination_lat;
      if (args.destination_lng) t.from_location = args.destination_lng;
      if (args.departure_date_time) t.from_location = args.departure_date_time;
      if (args.vehicle_id) t.vehicle_id = args.vehicle_id;
      var updatetrip = await Query.update('trips', {
        data: t,
        id: args.trip_id,
        driver_id: args.driver_id,
      });
      if (updatetrip.affectedRows > 0) {
        var trip = await Query.findsinglerecord('trips', {
          id: args.trip_id,
        });
        return trip;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.findtriplist = async function (args) {
  console.log('find trip ',args);
  let tripFindData = {
    user_id: args.user_id,
    user_address: args.user_address,
    user_lat: args.user_lat,
    user_lng: args.user_lng,
    user_destination_address: args.user_destination_address,
    user_destination_lat: args.user_destination_lat,
    user_destination_lng: args.user_destination_lng,
    user_departure_date_time: args.user_departure_date_time,
  };
  if(args.price_per_seat){
    tripFindData.price=args.price_per_seat;
  }

  let insertresult = await Query.insert('trip_search_query', {
    data: tripFindData,
  });
  var filter='';
  if(args.user_departure_date_time!='' && args.user_departure_date_time!='NaN')
  {
    var date_field=moment(args.user_departure_date_time).format('YYYY-MM-DD');
    if(date_field!=NaN || date_field!=undefined)
    {
    if(date_field!=NaN || date_field!=undefined)
      console.log('inside',date_field);
      filter=" and date(trips.departure_date_time)='"+date_field+"'";
    }
    else{
      // console.log('out');
    }
    
  }
  if(args.no_of_seats){
    filter=filter+" and trips.no_of_seat>="+args.no_of_seats;
  }
  // from and destination from same table

  // var queryForTripTable =
  //   "SELECT trips.id, trips.driver_id,trips.from_location,trips.from_lat,trips.from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.total_ride_taken as driver_total_ride_taken,vehicles.vehicle_type,round(SQRT( POW(69.1 * (trips.from_lat - " +
  //   args.user_lat +
  // "), 2) + POW(69.1 * (" +
  //   args.user_lng +
  //   " - trips.from_lng) * COS(trips.from_lat / 57.3), 2)),2) AS startPointDistance,trips.price,trips.no_of_seat,round(SQRT( POW(69.1 * (trips.destination_lat - " +
  //   args.user_destination_lat +
  //   "), 2) + POW(69.1 * (" +
  //   args.user_destination_lng +
  //   " - trips.destination_lng) * COS(trips.destination_lat / 57.3), 2)),2) AS endPointDistance FROM  `trips` LEFT JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id where trips.status='1' and users.status='1' and users.driver_id_verified=1 and trips.departure_date_time>= CURDATE()"+filter +" HAVING startPointDistance < 50 and endPointDistance <50 order by startPointDistance";

  // var queryForTripTableResult = await Query.queryForList(queryForTripTable);

  //    console.log("queryForTripTableResult",queryForTripTable)

  //from point in stop table and destination in trip table
  // var queryForTripStopTable =
  //   "select trips.id, trips.driver_id,trip_stops.destination_address as from_location,trip_stops.destination_lat as from_lat,trip_stops.destination_lng as from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.total_ride_taken as driver_total_ride_taken,vehicles.vehicle_type,round(SQRT( POW(69.1 * (trip_stops.destination_lat -  " +
  //   args.user_lat +
  //   "), 2) + POW(69.1 * (" +
  //   args.user_lng +
  //   " - trip_stops.destination_lng) * COS(trip_stops.destination_lat / 57.3), 2)),2) AS startPointDistance,trip_stops.price,trip_stops.no_of_seat,round(SQRT( POW(69.1 * (trips.destination_lat - " +
  //   args.user_destination_lat +
  //   "), 2) + POW(69.1 * (" +
  //   args.user_destination_lng +
  //   " - trips.destination_lng) * COS(trips.destination_lat / 57.3), 2)),2) AS endPointDistance FROM trip_stops LEFT JOIN trips on trips.id = trip_stops.trip_id LEFT JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id where trips.status='1' and users.status='1' and users.driver_id_verified=1 and trips.departure_date_time>= CURDATE()"+filter+" HAVING startPointDistance < 50 and endPointDistance < 50";

  // var queryForTripStopTableResult = await Query.queryForList(
  //   queryForTripStopTable
  // );
  // console.log("queryForTripStopTableResult",queryForTripStopTableResult)
  // from point in stop table in destination in stop table
  var queryForTripStopTableForStartAndEnd =
    "select trips.id, trips.driver_id,GROUP_CONCAT(trip_stops.id SEPARATOR ',') as stop_ids,trip_stops.destination_address as from_location,trip_stops.destination_lat as from_lat,trip_stops.destination_lng as from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.total_ride_taken as driver_total_ride_taken,vehicles.vehicle_type,round(SQRT( POW(69.1 * (trip_stops.destination_lat -  " +
    args.user_lat +
    "), 2) + POW(69.1 * (" +
    args.user_lng +
    " - trip_stops.destination_lng) * COS(trip_stops.destination_lat / 57.3), 2)),2) AS startPointDistance,trip_stops.price,round(SQRT( POW(69.1 * (trip_stops.destination_lat - " +
    args.user_destination_lat +
    "), 2) + POW(69.1 * (" +
    args.user_destination_lng +
    " - trip_stops.destination_lng) * COS(trip_stops.destination_lat / 57.3), 2)),2) AS endPointDistance,  (select COUNT(booked_seat.id) FROM booked_seat WHERE trip_id = trips.id and FIND_IN_SET(stop_id_from,GROUP_CONCAT(trip_stops.id SEPARATOR ',')) and FIND_IN_SET(stop_id_to,GROUP_CONCAT(trip_stops.id SEPARATOR ','))) as totalBooked,trip_stops.no_of_seat FROM trip_stops LEFT JOIN trips on trips.id = trip_stops.trip_id LEFT JOIN users on users.id = trips.driver_id  LEFT JOIN vehicles on vehicles.id = trips.vehicle_id where trips.status='1' and users.status='1' and users.driver_id_verified=1 and trips.departure_date_time>= CURDATE() "+filter+" GROUP BY id HAVING startPointDistance < 50 or endPointDistance < 50";

  var queryForTripStopTableForStartAndEndResult = await Query.queryForList(
    queryForTripStopTableForStartAndEnd
  );
  // console.log("queryForTripStopTableForStartAndEndResult",queryForTripStopTableForStartAndEnd);

  var finalTripList = [
    // ...queryForTripTableResult,
    // ...queryForTripStopTableResult,
    ...queryForTripStopTableForStartAndEndResult,
  ];

  if (finalTripList.length > 0) {
    // var list = [];
    // list.push(finalTripList);
    return { list: finalTripList, statusCode: 200, message: 'Trip List' };
  } else {
    return { list:[], statusCode: 200, message: 'No Trip Found, Post a request' };
    // var err = new Error(errorName.NOTFOUND);
    // throw err;
  }

};
exports.requestforbooking = async function (args) {
  var trip = await Query.findsinglerecord('trips', {
    id: args.trip_id,
  });
  if(trip){
    let tripBookingRequest = {
      trip_id: args.trip_id,
      rider_id: args.user_id,
      booked_seat: args.booked_seat,
      from_location: args.from_location,
      from_lat: args.from_lat,
      from_lng: args.from_lng,
      destination_address: args.destination_address,
      destination_lat: args.destination_lat,
      destination_lng: args.destination_lng,
      base_fare: args.base_fare,
      extra_amount: args.extra_amount,
      total_fare: args.total_fare,
      discount_amount: args.discount_amount,
      coupon_id: args.coupon_id,
      coupon_code: args.coupon_code,
      stop_id_from: args.stop_id_from,
      stop_id_to: args.stop_id_to,
      booking_status:'1'
    };  
  
    let insertresult = await Query.insert('bookings', {
      data: tripBookingRequest,
    });
  
    if (insertresult) {
      var trip = await Query.findsinglerecord('bookings', {
        id: insertresult.insertId,
      });
      return trip;
    } else {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }

  }else{
    var err = new Error(errorName.NOTFOUND);
      throw err;
  }
  
};
exports.createrequestfortrip = async function (args) {
 
  var unixTimestamp = Math.floor(new Date(args.departure_date_time).getTime()/1000);
  let createRequestForTrip = {
    user_id: args.user_id,
    from_address: args.from_location,
    from_lat: args.from_lat,
    from_lng: args.from_lng,
    destination_address: args.destination_address,
    destination_lat: args.destination_lat,
    destination_lng: args.destination_lng,
    departure_date_time: args.departure_date_time,
    departure_date_time_unix: unixTimestamp,
  };

  let insertresult = await Query.insert('trip_requests', {
    data: createRequestForTrip,
  });

  if (insertresult) {
    var trip = await Query.findsinglerecord('trip_requests', {
      id: insertresult.insertId,
    });
    return trip;
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};
exports.getmaxpriceforperseat = async function (args) {
  console.log('get fare',args);
  var queryForGetMaxPriceForSeat =
    'SELECT round(SQRT( POW(69.1 * ('+args.from_lat+' - '+args.destination_lat+'), 2) + POW(69.1 * ('+args.from_lng+' - '+args.destination_lng+') * COS('+args.from_lat+' / 57.3), 2)),2) AS total_distance, (select settings.per_km_max_amount from settings) as per_km_max_amount,(select settings.min_amount from settings) as min_amount ,(round(round(SQRT( POW(69.1 * ('+args.from_lat+' - '+args.destination_lat+'), 2) + POW(69.1 * ('+args.from_lng+' - '+args.destination_lng+') * COS('+args.from_lat+' / 57.3), 2)),2) * (select settings.per_km_max_amount from settings))) as max_price,(select settings.min_amount from settings) as min_amount';

  var queryForGetMaxPriceForSeatResult = await Query.queryForList(queryForGetMaxPriceForSeat);
  return queryForGetMaxPriceForSeatResult[0];
  
  // ;
};
exports.getrequesttriplist = async function (args) {
  console.log('request list',args);
  var filter='';
 if(args.user_departure_date_time)
 {
  var unixTimestamp = Math.floor(new Date(args.user_departure_date_time).getTime()/1000);
  filter="and trip_requests.departure_date_time_unix >="+unixTimestamp;
 }

 
  // console.log(unixTimestamp);
    // from and destination from request table
    var queryForTripRequestTable =
    "SELECT trip_requests.id, trip_requests.from_address,trip_requests.from_lat,trip_requests.from_lng,trip_requests.destination_address,trip_requests.destination_lat,trip_requests.destination_lng,users.id as user_id,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.about as driver_about,TIMESTAMPDIFF(YEAR, users.dob, CURDATE()) AS driver_age,users.gender as driver_gender,users.total_ride_taken as driver_total_ride_taken,users.user_id_verified,trip_requests.no_of_seat,trip_requests.departure_date_time,round(SQRT( POW(69.1 * (trip_requests.from_lat - " +
    args.user_lat +
    "), 2) + POW(69.1 * (" +
    args.user_lng +
    " - trip_requests.from_lng) * COS(trip_requests.from_lat / 57.3), 2)),2) AS startPointDistance,round(SQRT( POW(69.1 * (trip_requests.destination_lat - " +
    args.user_destination_lat +
    "), 2) + POW(69.1 * (" +
    args.user_destination_lng +
    "- trip_requests.destination_lng) * COS(trip_requests.destination_lat / 57.3), 2)),2) AS endPointDistance FROM  `trip_requests`  LEFT JOIN users on users.id = trip_requests.user_id where users.status='1' and trip_requests.departure_date_time>= CURDATE() "+filter+" HAVING startPointDistance < 50 and endPointDistance < 50 order by startPointDistance";

    var queryForTripRequestTableResult = await Query.queryForList(queryForTripRequestTable);
    
    if(queryForTripRequestTableResult.length > 0){
      var list = [];
      list.push(queryForTripRequestTableResult);
      return { list: queryForTripRequestTableResult, statusCode: 200, message: 'Trip Request List' };
    }else{
      return { list: [], statusCode: 200, message: 'Trip Request Not Found' };
    }
    

};
exports.gettripdetail = async function (args) {
    // get trip detail with driver profile
  var q="SELECT trips.price,trips.id,trips.from_location,trips.from_lat,trips.from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,trips.driver_id,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.about as driver_about,TIMESTAMPDIFF(YEAR, users.dob, CURDATE()) AS driver_age,users.gender as driver_gender,users.total_ride_taken as driver_total_ride_taken,CONCAT_WS('-', vehicles.model,vehicles.brand_name ) AS vehicle_name,CONCAT_WS(' ', vehicles.color,vehicles.model_year) AS vehicle_info,vehicles.photo as vehicle_photo,CASE trip_facilities.luggage_type when '1' then 'No' when '2' then 'Small' when '3' then 'medium' when '4' then 'Large'  ELSE '' END AS luggage_type,trip_facilities.back_side_seat_for_two_only,trip_facilities.smoking_allow,trip_facilities.reach_on_time,trip_facilities.drinking_allow,trip_facilities.pets_allow,trip_facilities.wear_face_mask from trips INNER JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id LEFT JOIN trip_facilities on trip_facilities.trip_id = trips.id WHERE trips.id = "+args.trip_id+"  group by trips.id"; 

  var qresult = await Query.queryForList(
    q
  );  
  console.log(qresult);  
  return { list: qresult[0], statusCode: 200, message: 'Trip Details' };
};
exports.canceltrip = async function (args) {
 
    var trecord = await Query.findsinglerecord('trips', {
      driver_id: args.driver_id,
      id: args.trip_id,
    });
    if (trecord) {
      var updateData = {
        status:"3"
      }
      var updatetrip = await Query.update('trips', {
        data: updateData,
        id: args.trip_id,
        driver_id: args.driver_id,
      });
      if (updatetrip.affectedRows > 0) {
        var updateBookingData = {
          booking_status:"3",
          cancelled_by:"1"
        }
        var updateBookingQuery = "update bookings set booking_status='3' , cancelled_by='1' where trip_id="+args.trip_id;
        var updateBooking = await Query.query(updateBookingQuery);
        var trip = await Query.findsinglerecord('trips', {
          id: args.trip_id,
        });
        return trip;
                
      } else {
        
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
 
};
exports.cancelbooking = async function (args) {
  
  var brecord = await Query.findsinglerecord('bookings', {
    rider_id: args.user_id,
    id: args.booking_id,
  });
  // console.log('inside log',args);
  if (brecord) {
    var updateData = {
      booking_status:"3",
      cancelled_by:"2"
    }
    var updatebooking = await Query.update('bookings', {
      data: updateData,
      id: args.booking_id,
      rider_id: args.user_id,
    });
    if (updatebooking.affectedRows > 0) {
      var booking = await Query.findsinglerecord('bookings', {
        id: args.booking_id,
      });
      //console.log(booking)
      return booking;
              
    } else {
      
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  } 
};
exports.gettriphistoryfordriver = async function (args) {

   var queryforlist = "SELECT status,id,from_location,destination_address,departure_date_time,(select count(id) as total_booking from bookings where id=trips.id) as total_booking_count FROM `trips` WHERE status ='"+args.status+"' and driver_id ="+args.user_id+" order by departure_date_time asc";
   console.log('queryforlist',queryforlist);
   var resultoflist = await Query.queryForList(queryforlist);
  
   if (resultoflist.length > 0) {
    
    return { list: resultoflist, statusCode: 200, message: 'Trip List' };
  } else {
    return { list:[], statusCode: 200, message: 'No Trip Found!' };
  } 
};
exports.gettripdetailforhistory = async function (args) {
  // get trip detail with driver profile
    
    var q="SELECT trips.price,trips.id,trips.from_location,trips.from_lat,trips.from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,trips.driver_id,trips.no_of_seat,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.about as driver_about,TIMESTAMPDIFF(YEAR, users.dob, CURDATE()) AS driver_age,users.gender as driver_gender,users.total_ride_taken as driver_total_ride_taken,CONCAT_WS('-', vehicles.model,vehicles.brand_name ) AS vehicle_name,CONCAT_WS(' ', vehicles.color,vehicles.model_year) AS vehicle_info,vehicles.photo as vehicle_photo,CASE trip_facilities.luggage_type when '1' then 'No' when '2' then 'Small' when '3' then 'medium' when '4' then 'Large'  ELSE '' END AS luggage_type,trip_facilities.back_side_seat_for_two_only,trip_facilities.smoking_allow,trip_facilities.reach_on_time,trip_facilities.drinking_allow,trip_facilities.pets_allow,trip_facilities.wear_face_mask from trips INNER JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id LEFT JOIN trip_facilities on trip_facilities.trip_id = trips.id WHERE trips.id = "+args.trip_id+"  group by trips.id"; 

  var qresult = await Query.queryForList(q);

  var getstops =
    "select destination_address,destination_lat,destination_lng,departure_date_time,no_of_seat,price from trip_stops where trip_id=" +
    args.trip_id;
  var getstopsresult = await Query.queryForList(getstops);
  var getbooking =
    "select bookings.id as booking_id,bookings.booked_seat,bookings.from_location,bookings.from_lat,bookings.from_lng,bookings.destination_address,bookings.destination_lat,bookings.destination_lng,bookings.base_fare,bookings.extra_amount,bookings.discount_amount,bookings.total_fare,bookings.coupon_id,bookings.coupon_code,bookings.message,bookings.payment_status,bookings.booking_status,bookings.remark,users.id as rider_id,users.first_name as rider_first_name,users.last_name as rider_last_name,CONCAT_WS(' ', users.first_name,users.last_name ) AS rider_full_name,users.user_id_verified,users.about as rider_about,users.email as rider_email,users.profile_pic as rider_profile_pic,users.mobile as rider_mobile,users.gender as rider_gender from bookings  left join users on users.id = bookings.rider_id where bookings.trip_id=" +
    args.trip_id;
    console.log('getbooking',getbooking);
  var getbookingresult = await Query.queryForList(getbooking);
  qresult[0].stops=getstopsresult;
  qresult[0].bookings=getbookingresult;
  qresult[0].total_booking_count=getbookingresult.length;
  // var result = {
  //   trip: qresult[0],
  //   stops: getstopsresult,
  //   bookings: getbookingresult,
  // };
  //console.log(qresult);
  return { list: qresult[0], statusCode: 200, message: "Trip Details" };
};
exports.accepttriprequest = async function (args) {
 
  var trecord = await Query.findsinglerecord('bookings', {
    id: args.booking_id,
  });
  if (trecord) {

    var updateBookingQuery = "update bookings set booking_status='1' where id="+args.booking_id;
    var updateBooking = await Query.query(updateBookingQuery);
    var booking = await Query.findsinglerecord('bookings', {
      id: args.booking_id,
    });
    var bookedSeats = [];
    for(var i = 0; i < booking.booked_seat; i++){
      var booked = {
        trip_id: booking.trip_id,
        booking_id: booking.id,
        stop_id_from: booking.stop_id_from,
        stop_id_to: booking.stop_id_to,
      };
      bookedSeats.push(booked);
    }
    if (bookedSeats.length > 0) {
      let bulkInsert = await Query.bulkInsert('booked_seat', {
        data: bookedSeats,
      });

      return { list: booking, statusCode: 200, message: "Booking Details" };
    }
   
    
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  }

};
exports.canceltriprequest = async function (args) {
 
  var trecord = await Query.findsinglerecord('bookings', {
    id: args.booking_id,
  });
  if (trecord) {

    var updateBookingQuery = "update bookings set booking_status='1' and remark="+args.remark+" where id="+args.booking_id;
    var updateBooking = await Query.query(updateBookingQuery);
    var booking = await Query.findsinglerecord('bookings', {
      id: args.booking_id,
    });
    return { list: booking, statusCode: 200, message: "Booking Details" };
    
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  }

};
exports.paymentpre = async function (args) {
  
  //console.log(args);return;
  const { data } = await curly.post('http://localhost/payment/pre.php', {
    postFields: JSON.stringify({ amount: args.amount,card: args.card,expiry_date: args.expiry_date}),
  });
  var result = JSON.parse(data);
  let paymentPre = {
    booking_id: args.booking_id,
    card_type: result.CardType,
    amount: result.TransAmount,
    transaction_number: result.TxnNumber,
    receiptid: result.ReceiptId,
    transaction_type: result.TransType,
    ref_num: result.ReferenceNum,
    response_code: result.ResponseCode,
    iso: result.ISO,
    message: result.Message,
    is_visa_debit: result.IsVisaDebit,
    auth_code: result.AuthCode,
    complete: result.Complete,
    transaction_date: result.TransDate,
    transaction_time: result.TransTime,
    ticket: result.Ticket,
    time_out: result.TimedOut,
    issuer_id: result.IssuerId,
  };
  
  let insertresult = await Query.insert('payment_pre', {
    data: paymentPre,
  });

  return { statusCode: 200, message: result.Message };
};
exports.paymentpreauth = async function (args) {
  

  var paymentPreAuth = await Query.findsinglerecord('payment_pre', {
    booking_id: args.booking_id,
    complete:'true'
  });
// console.log(paymentPreAuth.transaction_number)
//   return;
  //console.log(args);return;
  const { data } = await curly.post('http://localhost/payment/preauth.php', {
    postFields: JSON.stringify({ orderid: paymentPreAuth.receiptid,transaction_number: paymentPreAuth.transaction_number,amount: paymentPreAuth.amount}),
  });
  var result = JSON.parse(data);
  let paymentPreAuthData = {
    booking_id: paymentPreAuth.booking_id,
    payment_pre_id: paymentPreAuth.id,
    card_type: result.CardType,
    amount: result.TransAmount,
    transaction_number: result.TxnNumber,
    receiptid: result.ReceiptId,
    transaction_type: result.TransType,
    ref_num: result.ReferenceNum,
    response_code: result.ResponseCode,
    iso: result.ISO,
    message: result.Message,
    is_visa_debit: result.IsVisaDebit,
    auth_code: result.AuthCode,
    complete: result.Complete,
    transaction_date: result.TransDate,
    transaction_time: result.TransTime,
    ticket: result.Ticket,
    time_out: result.TimedOut,
    issuer_id: result.IssuerId,
  };
  
  let insertresult = await Query.insert('payment_preauth', {
    data: paymentPreAuthData  ,
  });

  return { statusCode: 200, message: result.Message };
};
exports.tripinvitaion = async function(args) {
  var invitations = [];
  
    args.user_ids.forEach((user_id) => {
      var invite = {
        trip_id: args.trip_id,
        driver_id: args.driver_id,
        user_id: user_id
      };
      invitations.push(invite);
    });
    
    if (invitations.length > 0) {
      let bulkInsert = await Query.bulkInsert('trip_invitation', {
        data: invitations,
      });

      return { statusCode: 200, message: 'Invitation send successfully' };
    }
};
exports.getinvitationlistforcustomer = async function (args) {
  
  var queryforlist = "SELECT trips.id,trips.from_location,trips.destination_address,trips.departure_date_time FROM `trips` left join trip_invitation on trip_invitation.trip_id = trips.id left join users on users.id = trip_invitation.user_id WHERE trips.departure_date_time>= CURDATE() and trips.status='1' and users.status='1' and trip_invitation.user_id ="+args.user_id;
  var resultoflist = await Query.queryForList(queryforlist);
  if (resultoflist.length > 0) {  
    return { list: resultoflist, statusCode: 200, message: 'Invitation List' };
  } else {
    return { list:[], statusCode: 200, message: 'No Invitation Found!' };
  } 

};
exports.testsms = async function (args) {
  var res=await COMMON.sendsms();
};
