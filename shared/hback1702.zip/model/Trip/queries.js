const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require('graphql');
const type = require('./type').schema;
const GraphQLJSON = require('graphql-type-json').GraphQLJSON;
const { errorName } = require('../../middleware/errorContant');
  const { validate, ValidationError } = require('validator-fluent');
// const User = require("./model");
const TripFunction = require('./function');
// const User = require("./users");
// Defines the queries
var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: 'BaseModel',
  description: 'Base model',
  fields: c_fields,
});
module.exports = {
  testsms: {
    type: home_schema,
    description: 'Test api for send sms',
    args: {
      mobile_number: { type: GraphQLString },
      message: { type: GraphQLString },
     
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        return TripFunction.testsms(args);
        
      }
     
    },
  },
  findtriplist: {
    type: home_schema,
    description: 'Retrieves Nearest trip list',
    args: {
      user_id: { type: GraphQLID },
      user_address: { type: GraphQLString },
      user_lat: { type: GraphQLString },
      user_lng: { type: GraphQLString },
      user_destination_address: { type: GraphQLString },
      user_destination_lat: { type: GraphQLString },
      user_destination_lng: { type: GraphQLString },
      user_departure_date_time: { type: GraphQLString },
      no_of_seats:{type:GraphQLInt}
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          user_lat: value('user_lat').notEmpty(),
          user_lng: value('user_lng').notEmpty(),
          user_destination_lat: value('user_destination_lat').notEmpty(),
          user_destination_lng: value('user_destination_lng').notEmpty(),
          //   trip_type: value("trip_type").notEmpty(),
          //   departure_date_time: value("departure_date_time").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.findtriplist(args);
        }
        
      }
     
    },
  },
  gettripdetail: {
    type: home_schema,
    description: 'Retrieves Trip Detail',
    args: {
      trip_id: { type: GraphQLID },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          trip_id: value('trip_id').notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.gettripdetail(args);
        }
        
      }
     
    },
  
  },
  getrequesttriplist:{
    type: home_schema,
    description: 'Retrieves Request trips by the riders',
    args: {
      user_lat: { type: GraphQLString },
      user_lng: { type: GraphQLString },
      user_destination_lat: { type: GraphQLString },
      user_destination_lng: { type: GraphQLString },
      user_departure_date_time: { type: GraphQLString },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          user_lat: value('user_lat').notEmpty(),
          user_lng: value('user_lng').notEmpty(),
          user_destination_lat: value('user_destination_lat').notEmpty(),
          user_destination_lng: value('user_destination_lng').notEmpty(),
      
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.getrequesttriplist(args);
        }
        
      }
     
    },
   
  },
  gettriphistoryfordriver:{
    type: home_schema,
    description: 'Retrieves trips by the riders with type like active completed and concelled as per passed status',
    args: {
      user_id: { type: GraphQLString },
      status: { type: GraphQLString }
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          user_id: value('user_id').notEmpty(),
          status: value('status').notEmpty(),          
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.gettriphistoryfordriver(args);
        }
        
      }
     
    },
  },
  gettripdetailforhistory:{
    type: home_schema,
    description: 'Retrieves trips details with all data like stop, booking etc.',
    args: {
      user_id: { type: GraphQLString },
      trip_id: { type: GraphQLString }
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          user_id: value('user_id').notEmpty(),
          trip_id: value('trip_id').notEmpty(),          
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.gettripdetailforhistory(args);
        }
        
      }
     
    },
  },
  getinvitationlistforcustomer:{
      type: home_schema,
      description: 'Get invitation list',
      args: {
        user_id: { type: GraphQLID },
      },
      resolve: async (parent, args, { verifiedUser }) => {
        if (!verifiedUser) {
          var err = new Error(errorName.UNAUTHRIZED);
          throw err;
        } 
        else{
          const [data, errors] = validate(args, (value) => ({
            user_id: value('user_id').notEmpty(),
          }));

          if (Object.keys(errors).length > 0) {
            throw new ValidationError(errors);
          } else {
            args.token_user_id = verifiedUser.user_id;
            return TripFunction.getinvitationlistforcustomer(args);
          }
          
        }
    },
  }
}
