const jwt = require('jsonwebtoken');
const moment = require('moment');
const Query = require('../../lib/query');
const { errorName } = require('../../middleware/errorContant');

exports.addvehicle = async function (args) {
  if (args.driver_id == args.token_user_id) {
    var userdata = await Query.findsinglerecord('users', {
      id: args.token_user_id,
    });
    if (userdata) {
      // check driver profile is active or not
      if (userdata.status == '1') {
      
          let vData = {
            driver_id: args.driver_id,
            model: args.model,
            vehicle_type: args.vehicle_type,
            photo: args.photo,
            color: args.color,
            model_year: args.model_year,
            luggage_status: args.luggage_status,
            backrow_seating_status: args.backrow_seating_status,
            others: args.others,
            registration_number: args.registration_number,
            total_seat: args.total_seat,
            fuel_type: args.fuel_type,
            ac: args.ac,
          };
          let insertresult = await Query.insert('vehicles', {
            data: vData,
          });

          if (insertresult.affectedRows > 0) {
            
            var vehicle = await Query.findsinglerecord('vehicles', {
              id: insertresult.insertId,
            });
            return vehicle;
          } else {
            var err = new Error(errorName.WENT_WRONG);
            throw err;
          }
        
      } else {
        var err = new Error(errorName.ACCOUNT_NOT_ACTIVE);
        throw err;
      }
    }
    else {
      var err = new Error(errorName.UNAUTHRIZED);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};

exports.updatevehicle = async function (args) {
 
  if (args.driver_id == args.token_user_id) {
    var vrecord = await Query.findsinglerecord('vehicles', {
      driver_id: args.token_user_id,
      id: args.vehicle_id,
    });
    console.log('args',vrecord);
    if (vrecord) {
      var t = {};
      if (args.model) t.model = args.model;
      if (args.vehicle_type) t.vehicle_type = args.vehicle_type;
      if (args.photo) t.photo = args.photo;
      if (args.color) t.color = args.color;
      if (args.model_year) t.model_year = args.model_year;
      if (args.luggage_status) t.luggage_status = args.luggage_status;
      if (args.backrow_seating_status) t.backrow_seating_status = args.backrow_seating_status;
      if (args.others) t.others = args.others;
      if (args.registration_number) t.registration_number = args.registration_number;
      if (args.total_seat) t.total_seat = args.total_seat;
      if (args.fuel_type) t.fuel_type = args.fuel_type;
      if (args.ac) t.ac = args.ac;
      if (args.status) t.status = args.status;
      var updatetrip = await Query.update('vehicles', {
        data: t,
        id: args.vehicle_id,
        driver_id: args.driver_id,
      });
      if (updatetrip.affectedRows > 0) {
        var vehicle = await Query.findsinglerecord('vehicles', {
          id: args.vehicle_id,
        });
        return vehicle;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.vehicledetail = async function (args) {
  if (args.driver_id == args.token_user_id) {
    var vehicle = await Query.findsinglerecord('vehicles', {
      id: args.vehicle_id,
      driver_id: args.driver_id,
    });
    if (vehicle) {
      return vehicle;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.findall = async function (args) {
  if (args.driver_id == args.token_user_id) {
    var vdata = await Query.findByFields('vehicles', {
      driver_id:args.driver_id
    });
    if (vdata.length > 0) {
      // console.log('vadata',vdata);
      return vdata;
    } else {

      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};

