const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLInt,
  GraphQLFloat,
} = require("graphql");
const Offer = require("./offer");
const type = require("./type").schema;
const mySQLWrapper = require("../../lib/mysqlWrapper");
const commonfunction = require("../../shared/common");
// Defines the queries
module.exports = {
  promolist: {
    type,
    args: {
      user_id: {
        type: GraphQLString,
      },
      cart_amount: { type: GraphQLInt },
    },
    resolve: async (parent, args) => {
      let baseQuery = `select o.* from offers o where end_to>=CURDATE() and visibility='1' and status='1' and o.pending_count>0 and o.coupon_code!='' `;
      baseQuery += " order by o.display_order_no asc";
      try {
        var promolist = await mySQLWrapper.createQuery({
          query: baseQuery,
        });

        if (promolist.length > 0) return { list: promolist };
        else return { list: [], message: "No Coupon Found" };
      } catch (e) {
        const error = new Error("Something Went Wrong");
        error.code = 404;
        throw error;
      }
      // return Offer.promolist(args);
    },
  },
  applypromo: {
    type,
    args: {
      user_id: { type: new GraphQLNonNull(GraphQLString) },
      cart_amount: { type: new GraphQLNonNull(GraphQLInt) },
      coupon_code: { type: new GraphQLNonNull(GraphQLString) },
    },
    resolve: async (parent, args) => {
      return Offer.applypromo(args);
    },
  },
};
