const e = require("cors");
var Commonlib = require("../../lib/query");
const mySQLWrapper = require("../../lib/mysqlWrapper");
const moment = require("moment");
class Offer {
  static async applypromo(fields) {
    if (fields.user_id && fields.cart_amount && fields.coupon_code) {
      var is_valid_res = await this.validateCoupon(
        fields.coupon_code,
        fields.user_id,
        fields.cart_amount
      );

      var is_valid_coupon = is_valid_res.is_valid;

      if (is_valid_coupon) {
        return {
          statusCode: 200,
          discount_amount: is_valid_res.discount,
          message: is_valid_res.msg,
          coupon_id: is_valid_res.coupon_id,
        };
      } else {
        var error_msg = is_valid_res.msg;
        const error = new Error(error_msg);
        error.code = 404;
        throw error;
      }
    } else {
      const error = new Error("Required Parameter missing");
      error.code = 404;
      throw error;
    }
  }

  static async validateCoupon(coupon_code, user_id, cart_amount) {
    coupon_code = coupon_code.toUpperCase();

    var couponcheck = await Commonlib.findByFields("offers", {
      coupon_code: coupon_code,
      status: "1",
    });

    var is_valid = true;
    var v_s = {
      is_valid: false,
      msg: "Try again after some time",
    };
    if (couponcheck.length > 0) {
      var cp = couponcheck[0];
      if (cp.pending_count <= 0) {
        var is_valid = false;
        var v_s = {
          is_valid: false,
          msg: "This coupon is expired, Use another coupon ",
        };
        return v_s;
      }
      var coupon_id = cp.id;
      var current_date = moment.utc(new Date()).format("YYYY-MM-DD");
      var from_date = moment.utc(cp.start_from).format("YYYY-MM-DD");
      var end_date = moment.utc(cp.end_to).format("YYYY-MM-DD");
      var cph = await Commonlib.findByFields("orders", {
        coupon_id: coupon_id,
      });
      var cphs = await Commonlib.findByFields("bookings", {
        coupon_id: coupon_id,
        rider_id: user_id,
      });

      // if (cph && cph.length >= cp.use_per_coupon) {
      //   var is_valid = false;
      //   var v_s = {
      //     is_valid: false,
      //     msg: "Coupon is already used",
      //   };
      //   return v_s;
      // }
      if (cphs && cphs.length >= cp.use_per_user) {
        var is_valid = false;
        var v_s = {
          is_valid: false,
          msg: "You Already used this coupon, Please try another Coupon",
        };
        return v_s;
      }
      if (current_date > end_date || current_date < from_date) {
        var is_valid = false;
        var v_s = {
          is_valid: false,
          msg: "Coupon Expired  ",
        };
        return v_s;
      }

      if (cp.min_amount > 0) {
        if (cp.min_amount > cart_amount) {
          var is_valid = false;
          var msg = "Add Rs " + cp.min_amount + " more to avail this Coupon";
          var v_s = {
            is_valid: false,
            msg: msg,
          };
          return v_s;
        }
      }

      if (cp.max_amount > 0) {
        if (cp.max_amount < cart_amount) {
          var is_valid = false;
          var msg =
            "Coupon is valid only up to cart value of " + cp.max_amount + " Rs";
          var v_s = {
            is_valid: false,
            msg: msg,
          };
          return v_s;
        }
      }

      if (is_valid) {
        if (cp.offer_type == "1") {
          var cp_amt = cp.discount_amount;
          var discount = (cart_amount * cp_amt) / 100;
          var discount = parseInt(discount).toFixed(2);
        } else {
          var discount = cp.discount_amount;
        }
        var v_s = {
          is_valid: true,
          coupon_id: cp.id,
          discount: discount,
          msg: "Coupon Applied",
        };
      }
    } else {
      var is_valid = false;
      var v_s = {
        is_valid: false,
        msg: "Invalid Promo Code",
      };
    }

    return v_s;
  }
}
module.exports = Offer;
