let {
    GraphQLID,
    GraphQLString,
    GraphQLFloat,
    GraphQLInt,
    GraphQLObjectType,
    GraphQLNonNull,
    GraphQLList,
    GraphQLEnumType,
    GraphQLBoolean,
} = require("graphql");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

var common_fields = {
    list: {
        type: GraphQLJSON,
    },
    subject: {
        type: GraphQLString,
    },
    reason_for: {
        type: GraphQLString,
    },
    status: {
        type: GraphQLString,
    },
    issue_id: {
        type: GraphQLInt,
    },
    statusCode: {
        type: GraphQLInt,
    },
    message: {
        type: GraphQLString,
    },
};

// Defines the type
var c_schema = new GraphQLObjectType({
    name: "Issue",
    description: "Issue List",
    fields: common_fields,
});

module.exports = {
    schema: c_schema,
    common_fields: common_fields,
};
