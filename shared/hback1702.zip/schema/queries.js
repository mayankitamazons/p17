const { GraphQLObjectType } = require("graphql");
const Userquires = require("../model/User/queries");
const Tripquires = require("../model/Trip/queries");
const Bookingquires = require("../model/Booking/queries");
const Vehiclequires = require("../model/Vehicle/queries");
const HelpQuery = require("../model/help/queries");
const PromoQuery = require("../model/offers/queries");
const IssueQuery = require("../model/issues/queries");
const ChatsQuery = require("../model/chat/queries");
// const Categoryquires = require("../model/Category/queries");
// const Collectionquires = require("../model/Collection/queries");

module.exports = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    // users: Userquires.users,
    user: Userquires.user,
    verificationdetail: Userquires.verificationdetail,
    findtriplist: Tripquires.findtriplist,
    gettripdetail: Tripquires.gettripdetail,
    getrequesttriplist: Tripquires.getrequesttriplist,
    gettriphistoryfordriver: Tripquires.gettriphistoryfordriver,
    gettripdetailforhistory: Tripquires.gettripdetailforhistory,
    getinvitationlistforcustomer: Tripquires.getinvitationlistforcustomer,
    getbookinghistoryforuser: Bookingquires.getbookinghistoryforuser,
    getbookingdetailforhistory: Bookingquires.getbookingdetailforhistory,
    vehicle: Vehiclequires.vehicle,
    vehiclelist: Vehiclequires.vehiclelist,
    helpMenu: HelpQuery.helpmenu,
    promolist: PromoQuery.promolist,
    getIssueSubject: IssueQuery.getIssueSubject,
    getIssueSubSubject: IssueQuery.getIssueSubSubject,
    getIssueChat: IssueQuery.getIssueChat,
    getchatlist: ChatsQuery.getchatlist,
  },
});
