const { GraphQLObjectType } = require("graphql");
const UserMutation = require("../model/User/mutations");
const TripMutation = require("../model/Trip/mutations");
const VehicleMutation = require("../model/Vehicle/mutations");
const PromoQuery = require("../model/offers/queries");
const Issue = require("../model/issues/mutations");
const Chat = require("../model/chat/mutations");
module.exports = new GraphQLObjectType({
  name: "RootMutationsType",
  fields: {
    register: UserMutation.register,
    login: UserMutation.login,
    socialogin: UserMutation.socialogin,
    forgotpassword: UserMutation.forgotpassword,
    resetpassword: UserMutation.resetpassword,
    changepassword: UserMutation.changepassword,
    usercheck: UserMutation.usercheck,
    updateuser: UserMutation.updateuser,
    submitidverification: UserMutation.submitidverification,
    sendemailverificationmail: UserMutation.sendemailverificationmail,
    verifyemailtoken: UserMutation.verifyemailtoken,
    createtripstepone: TripMutation.createtripstepone,
    createtripstetwo: TripMutation.createtripsteptwo,
    // createtripstepthree: TripMutation.createtripstepthree,
    createtripstepfinal: TripMutation.createtripstepfinal,
    updatetrip: TripMutation.updatetrip,
    requestforbooking: TripMutation.requestforbooking,
    createrequestfortrip: TripMutation.createrequestfortrip,
    getmaxpriceforperseat: TripMutation.getmaxpriceforperseat,
    canceltrip: TripMutation.canceltrip,
    cancelbooking: TripMutation.cancelbooking,
    accepttriprequest: TripMutation.accepttriprequest,
    canceltriprequest: TripMutation.canceltriprequest,
    paymentpre: TripMutation.paymentpre,
    paymentpreauth: TripMutation.paymentpreauth,
    tripinvitaion: TripMutation.tripinvitaion,
    addvehicle: VehicleMutation.addvehicle,
    updatevehicle: VehicleMutation.updatevehicle,
    applypromo: PromoQuery.applypromo,
    submitIssue: Issue.submitIssue,
    submitIssueChat: Issue.submitIssueChat,
    createchat: Chat.createchat,
  },
});
