const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const bcrypt = require("bcrypt");
const { createJwtToken } = require("../../util/auth");
const { errorName } = require("../../middleware/errorContant");
const COMMON = require("../../shared/common");
const validator = require("../../helper/validate");
const { relativeTimeRounding } = require("moment");
const { filter } = require("async");
const { off } = require("../../lib/db");

exports.changestatus = async function (args) {
  var updatedata = {};
  updatedata.status = args.status;
  if (args.remark) updatedata.remark = args.remark;
  console.log(updatedata);
  var updateprofile = await Query.update("users", {
    data: updatedata,
    id: args.user_id,
  });
  console.log(updateprofile);
  if (updateprofile.affectedRows > 0) {
    var user = await Query.findsinglerecord("users", {
      id: args.user_id,
    });
    return user;
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};
exports.changeactivationationstatus = async function (args) {
  // console.log('args',args)
  var singleData = await Query.findByFields(
    "user_verifications",
    { user_id: args.driver_id },
    1,
    0,
    { direction: "DESC", by: "id" }
  );
  if (singleData.length > 0) {
    var doc_id = singleData[0].id;
    var vdata = {};
    vdata.status = args.status;
    if (args.remark) vdata.remark = args.remark;
    // console.log('vdata',vdata)
    var updateverficationdata = await Query.update("user_verifications", {
      data: vdata,
      id: doc_id,
    });
    if (updateverficationdata.affectedRows > 0) {
      var updatedata = {};
      if (args.status == 1) updatedata.driver_id_verified = 1;
      else updatedata.driver_id_verified = 0;
      var updateprofile = await Query.update("users", {
        data: updatedata,
        id: args.driver_id,
      });

      if (updateprofile.affectedRows > 0) {
        var user = await Query.findsinglerecord("users", {
          id: args.driver_id,
        });

        return user;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } else {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  }
};

exports.userdetail = async function (args) {
  if (args.user_id == args.token_user_id) {
    var user = await Query.findsinglerecord("users", {
      id: args.token_user_id,
    });
    if (user) {
      return user;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.login = async function (fields) {
  var query = {};
  var errorCode = "NOTFOUND";
  if (fields.email) {
    query.email = fields.email;
    errorCode = "email";
  } else if (fields.mobile) {
    query.mobile = fields.mobile;
    errorCode = "mobile";
  }
  var user = await Query.findsinglerecord("admin", query);
  // var p = bcrypt.hashSync(fields.password, 10);
  // console.log("userdata", p);
  // return;
  if (user) {
    if (fields.email) {
      const validPassword = await bcrypt.compare(
        fields.password,
        user.password
      );
      if (!validPassword) {
        var err = new Error(errorName.PASSWORD_WRONG);
        throw err;
      }
    }
    const token = createJwtToken({
      user_id: user.id,
      first_name: user.first_name,
      mobile: user.mobile,
    });
    user.token = token;
    user.message = "Login Done";
    user.statusCode = 200;
    return user;
  } else {
    if (errorCode == "email") {
      var err = new Error(errorName.EMAIL_NOT_EXIT);
      throw err;
    } else if (errorCode == "mobile") {
      var err = new Error(errorName.MOBILE_NOT_EXIT);
      throw err;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  }
};
exports.register = async function (args) {
  var go_ahead = true;
  if (args.mobile && go_ahead) {
    // Mobile login
    var mobilecheck = await Query.findsinglerecord("admin", {
      mobile: args.mobile,
    });
    if (mobilecheck) {
      var err = new Error(errorName.MOBILE_EXIT);
      throw err;

      go_ahead = false;
    }
  }
  if (args.email && go_ahead) {
    // Email login
    var usercheck = await Query.findsinglerecord("admin", {
      email: args.email,
    });
    // console.log("email already", usercheck);
    if (usercheck) {
      var err = new Error(errorName.EMAIL_EXIT);
      throw err;
    }
  }
  if (go_ahead) {
    try {
      args.password = bcrypt.hashSync(args.password, 10);
      let insertresult = await Query.insert("admin", {
        data: args,
      });
      if (insertresult.affectedRows > 0) {
        args.id = insertresult.insertId;
        args.token = createJwtToken({
          user_id: args.id,
          first_name: args.first_name,
          mobile: args.mobile,
        });
        return args;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } catch (e) {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};

exports.dashboard = async function (args) {
  if (args.user_id == args.token_user_id) {
    // var queryforlist = "";
    // console.log('q',queryforlist);
    // var resultoflist = await Query.queryForList(queryforlist);
    const r = {
      monthly_passenger_charge: "32.32",
      monthly_booking_fee_earned: "32.32",
      monthly_payout_gross: "10,000",
      monthly_payout_commission: "10,000",
      monthly_unmatch_rides: "10,000",
      monthly_passenger_cancelled: "10,000",
      monthly_driver_cancelled: "10,000",
      total_ride_ytd: "500",
      total_ride_scheduled: "500",
      total_ride_scheduled: "500",
      total_km_shared: "50,000 KM",
      total_gas_saving: "50,000",
      total_gas_saving: "50,000",
      unmatch_rides: 50,
      passenger_cancelled_count: "20",
      driver_cancelled_count: "20",
      current_month_user_count: "20",
      total_users_count: "20",
      total_approved_driver_count: "20",
      total_approved_user_count: "20",
      total_suspended_count: "20",
    };
    const u_list = [
      {
        user_id: 1,
        name: "Raj",
        profile_pic: "",
        joining_date: "12/02/2023 12:00 PM",
        dob: "22/02/2023 12:00 PM",
      },
      {
        user_id: 2,
        name: "Raj 2",
        profile_pic: "",
        joining_date: "12/02/2023 12:00 PM",
        dob: "22/02/2023 12:00 PM",
      },
    ];
    r.recent_users = u_list;
    const top_routes = [
      {
        fron: "A ",
        to: "B",
        booking_count: 500,
      },
      {
        fron: "C ",
        to: "D",
        booking_count: 20,
      },
    ];
    r.top_routes = top_routes;
    return { list: r, statusCode: 200, message: " List" };
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
exports.userlist = async function (args) {
  // console.log("args", args);
  var listResult = [];
  if (args.filter == "driverpendingverification") {
    var query =
      "SELECT user_verifications.*,users.* FROM `user_verifications` inner join users on users.id=user_verifications.user_id where user_verifications.doc_type='driver' and user_verifications.status='0' and users.driver_id_verified=0 ";
    if (args.order) {
      query = query + "order by " + args.order.by + " " + args.order.direction;
    }
    var RecordCount = await Query.queryForList(query);
    if (RecordCount.length > 0) {
      if (args.limit && args.offset) {
        query =
          query + " limit " + args.offset * args.limit + " ," + args.limit;
      }

      var listResult = await Query.queryForList(query);
    }
  } else {
    var RecordCount = await Query.findByFields("users", args.condition);
    var listResult = await Query.findByFields(
      "users",
      args.condition,
      args.limit,
      args.offset,
      args.order
    );
  }
  if (listResult.length > 0) {
    // var list = [];
    // list.push(listResult);
    return {
      list: listResult,
      statusCode: 200,
      message: "User List",
      totalRecord: RecordCount.length,
    };
  } else {
    return {
      list: [],
      statusCode: 200,
      message: "No List Found, Post a request",
      totalRecord: 0,
    };
  }
};
