const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const { errorName } = require("../../middleware/errorContant");

exports.triplist = async function (args) {
  var filter='';
  if(args.status)
  filter=filter+" and trips.status="+args.status;
  if(args.driver_id)
  filter=filter+" and driver_id="+args.driver_id;
  var queryforlist = "SELECT trips.status,trips.id,from_location,destination_address,departure_date_time,driver.first_name,driver.last_name,driver.profile_pic FROM `trips` inner join users as driver on driver.id=trips.driver_id WHERE 1=1 "+filter;
  console.log('q',queryforlist);
  var resultoflist = await Query.queryForList(queryforlist);
 
  if (resultoflist.length > 0) {
   
   return { list: resultoflist, statusCode: 200, message: 'Trip List' };
 } else {
   return { list:[], statusCode: 200, message: 'No Trip Found!' };
 } 
};
exports.gettripdetail = async function (args) {
  // get trip detail with driver profile
var q="SELECT trips.price,trips.id,trips.from_location,trips.from_lat,trips.from_lng,trips.destination_address,trips.destination_lat,trips.destination_lng,trips.departure_date_time,trips.return_date_time,trips.driver_id,CONCAT_WS(' ', users.first_name,users.last_name ) AS driver_full_name,users.profile_pic as driver_profile_pic,users.rating as driver_rating,users.about as driver_about,TIMESTAMPDIFF(YEAR, users.dob, CURDATE()) AS driver_age,users.gender as driver_gender,users.total_ride_taken as driver_total_ride_taken,CONCAT_WS('-', vehicles.model,vehicles.brand_name ) AS vehicle_name,CONCAT_WS(' ', vehicles.color,vehicles.model_year) AS vehicle_info,vehicles.photo as vehicle_photo,CASE trip_facilities.luggage_type when '1' then 'No' when '2' then 'Small' when '3' then 'medium' when '4' then 'Large'  ELSE '' END AS luggage_type,trip_facilities.back_side_seat_for_two_only,trip_facilities.smoking_allow,trip_facilities.reach_on_time,trip_facilities.drinking_allow,trip_facilities.pets_allow,trip_facilities.wear_face_mask from trips INNER JOIN users on users.id = trips.driver_id LEFT JOIN vehicles on vehicles.id = trips.vehicle_id LEFT JOIN trip_facilities on trip_facilities.trip_id = trips.id WHERE trips.id = "+args.trip_id+"  group by trips.id"; 

var qresult = await Query.queryForList(
  q
);  
//console.log(qresult);  
return { list: qresult[0], statusCode: 200, message: 'Trip Details' };
};
