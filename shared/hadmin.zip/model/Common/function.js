const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const bcrypt = require("bcrypt");
const { createJwtToken } = require("../../util/auth");
const { errorName } = require("../../middleware/errorContant");
const COMMON = require("../../shared/common");
const validator = require("../../helper/validate");
const { relativeTimeRounding } = require("moment");
const { filter } = require("async");
const { json } = require("body-parser");

exports.getcount = async function (args) {
  var totalcountResult = await Query.getcount(args.table, args.condition);
  var totalcount = totalcountResult[0].totalCount;
  if (totalcountResult[0]) {
    return { totalcount: totalcountResult[0].totalCount };
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  }
};
exports.getsinglerecord = async function (args) {
  var listResult = await Query.findByFields(args.table, args.condition);
  if (listResult.length > 0) {
    // var list = [];
    // list.push(listResult);
    return {
      list: listResult[0],
      statusCode: 200,
      message: "Record Found",
      totalRecord: listResult.length,
    };
  } else {
    return {
      list: [],
      statusCode: 200,
      message: "No List Found, Post a request",
      totalRecord: 0,
    };
  }
};
exports.getlist = async function (args) {
  // total record
  var RecordCount = await Query.findByFields(args.table, args.condition);
  if (RecordCount.length > 0) {
    var listResult = await Query.findByFields(
      args.table,
      args.condition,
      args.limit,
      args.offset,
      args.order
    );
    if (listResult.length > 0) {
      // var list = [];
      // list.push(listResult);
      return {
        list: listResult,
        statusCode: 200,
        message: "Trip List",
        totalRecord: RecordCount.length,
      };
    } else {
      return {
        list: [],
        statusCode: 200,
        message: "No List Found, Post a request",
        totalRecord: 0,
      };
    }
  } else {
    return {
      list: [],
      statusCode: 200,
      message: "No List Found, Post a request",
      totalRecord: 0,
    };
  }
};
exports.update = async function (args) {
  var commonupdate = await Query.commonupdate(
    args.table,
    args.condition,
    args.update
  );
  if (commonupdate.affectedRows > 0) {
    return { statusCode: 200, message: "Update successfully" };
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};
exports.insert = async function (args) {
  let insertresult = await Query.commoninsert(args.table, args.fields);

  if (insertresult.affectedRows > 0) {
    return { statusCode: 200, message: "Insert successfully" };
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};
