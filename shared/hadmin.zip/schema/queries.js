const { GraphQLObjectType } = require("graphql");
const Userquires = require("../model/User/queries");
const Tripquires = require("../model/Trip/queries");
const Vehiclequires = require("../model/Vehicle/queries");
const Commonquires = require("../model/Common/queries");
// const Categoryquires = require("../model/Category/queries");
// const Collectionquires = require("../model/Collection/queries");

module.exports = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    dashboard: Userquires.dashboard,
    user: Userquires.user,
    userlist: Userquires.userlist,
    getlist: Commonquires.getlist,
    getsinglerecord: Commonquires.getsinglerecord,
    triplist: Tripquires.triplist,
    gettripdetail: Tripquires.gettripdetail,
  },
});
